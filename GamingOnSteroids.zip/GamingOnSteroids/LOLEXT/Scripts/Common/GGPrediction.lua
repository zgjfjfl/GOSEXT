local Version = 777
local Name = "GGPrediction"

if _G.GGPrediction then
	return
end

local math_huge = math.huge
local math_pi = math.pi
local math_sqrt = assert(math.sqrt)
local math_abs = assert(math.abs)
local math_min = assert(math.min)
local math_max = assert(math.max)
local math_pow = assert(math.pow)
local math_atan = assert(math.atan)
local math_acos = assert(math.acos)
local table_remove = assert(table.remove)
local table_insert = assert(table.insert)
local Game, Vector, Callback = _G.Game, _G.Vector, _G.Callback
local Menu, Immobile, Math, Path, UnitData, ObjectManager, Collision, Prediction, AoePrediction, YasuoWall
local COLLISION_MINION = 0
local COLLISION_ALLYHERO = 1
local COLLISION_ENEMYHERO = 2
local COLLISION_YASUOWALL = 3
local HITCHANCE_IMPOSSIBLE = 0
local HITCHANCE_COLLISION = 1
local HITCHANCE_NORMAL = 2
local HITCHANCE_HIGH = 3
local HITCHANCE_VERY_HIGH = 4
local HITCHANCE_DASHING = 5
local HITCHANCE_IMMOBILE = 6
local SPELLTYPE_LINE = 0
local SPELLTYPE_CIRCLE = 1
local SPELLTYPE_CONE = 2

YasuoWall = {
	HasYasuo = false,
	Hero = nil,
	wallCastPos = nil,
	wallPos = nil,
	wallLevel = 0,
	wallCastTime = 0,
	LastScanTime = 0,
	WALL_DURATION = 4,
	SCAN_INTERVAL = 0.1,
}

function YasuoWall:OnEnemyHeroLoad(args)
	if args.charName == "Yasuo" then
		self.HasYasuo = true
		self.Hero = args.unit
	end
end

function YasuoWall:OnTick()
	if not self.HasYasuo or not ObjectManager:IsValid(self.Hero) or self.Hero.distance > 2000 then
		return
	end
	local currentTime = Game.Timer()
	if self.wallCastTime > 0 and currentTime - self.wallCastTime > self.WALL_DURATION then
		self.wallLevel = 0
		self.wallCastTime = 0
		self.wallCastPos = nil
		self.wallPos = nil
	end
	if currentTime - self.LastScanTime < self.SCAN_INTERVAL then
		return
	end
	self.LastScanTime = currentTime
	if self.wallLevel == 0 then
		self.wallLevel = self.Hero:GetSpellData(_W).level
	end
	local pCount = Game.ParticleCount()
	for i = 1, pCount do
		local obj = Game.Particle(i)
		if obj and obj.pos then
			local name = obj.name
			if name then
				local lower = name:lower()
				if lower:find("yasuo", 1, true) and lower:find("windwall", 1, true) then
					if lower:find("activate", 1, true) then
						if not self.wallCastPos then
							self.wallCastPos = Math:Get2D(obj.pos)
						end
						if self.wallCastTime == 0 then
							self.wallCastTime = currentTime
						end
					else
						self.wallPos = obj.pos
					end
				end
			end
		end
	end
end

function YasuoWall:IsWallActive()
	return self.HasYasuo and self.wallCastPos and self.wallPos and Game.Timer() - self.wallCastTime <= self.WALL_DURATION
end

function YasuoWall:CheckCollision(source, castPos)
	if not self:IsWallActive() then
		return false
	end
	local Pos = Math:Get2D(self.wallPos)
	local Width = 250 + 70 * self.wallLevel + 80
	local Direction = Math:Perpendicular(Math:Normalized(Pos, self.wallCastPos))
	local StartPos = Math:Extended(Pos, Direction, Width / 2)
	local EndPos = Math:Extended(StartPos, Direction, -Width)
	local IntersectionResult = Math:Intersection(StartPos, EndPos, source, castPos)
	return IntersectionResult.Intersects
end

-- stylua: ignore start
local __menu = MenuElement({name = "GG Prediction", id = "GGPrediction", type = _G.MENU})

Menu =
{
	MaxRange = __menu:MenuElement({id = "PredMaxRange" .. myHero.charName, name = "Pred Max Range %", value = 100, min = 70, max = 100, step = 1}),
	Latency = __menu:MenuElement({id = "Latency", name = "Ping/Latency", value = 50, min = 0, max = 200, step = 5}),
	ExtraDelay = __menu:MenuElement({id = "ExtraDelay", name = "Extra Delay", value = 60, min = 0, max = 100, step = 5}),
	VersionA = __menu:MenuElement({name = '', type = _G.SPACE, id = 'VersionSpaceA'}),
	VersionB = __menu:MenuElement({name = 'Version  ' .. Version, type = _G.SPACE, id = 'VersionSpaceB'}),
}
-- stylua: ignore end

function Menu:GetMaxRange()
	local result = self.MaxRange:Value() * 0.01
	return result
end

function Menu:GetLatency()
	local result = Game.Latency() < 250 and Game.Latency() or Menu.Latency:Value()
	return result * 0.001
end

function Menu:GetExtraDelay()
	-- local result = self.ExtraDelay:Value() * 0.001
	return 0.06
end
--[[
enum class BuffType {
	Internal = 0,
	Aura = 1,
	CombatEnchancer = 2,
	CombatDehancer = 3,
	SpellShield = 4,
	Stun = 5,
	Invisibility = 6,
	Silence = 7,
	Taunt = 8,
	Berserk = 9,
	Polymorph = 10,
	Slow = 11,
	Snare = 12,
	Damage = 13,
	Heal = 14,
	Haste = 15,
	SpellImmunity = 16,
	PhysicalImmunity = 17,
	Invulnerability = 18,
	AttackSpeedSlow = 19,
	NearSight = 20,
	Currency = 21,
	Fear = 22,
	Charm = 23,
	Poison = 24,
	Suppression = 25,
	Blind = 26,
	Counter = 27,
	Shred = 28,
	Flee = 29,
	Knockup = 30,
	Knockback = 31,
	Disarm = 32,
	Grounded = 33,
	Drowsy = 34,
	Asleep = 35,
	Obscured = 36,
	ClickProofToEnemies = 37,
	Unkillable = 38
};
--]]

Immobile = {
	IMMOBILE_TYPES = {
		[5] = true,
		[8] = true,
		-- [9] = true,
		[12] = true,
		[23] = true,
		[25] = true,
		-- [29] = true,
		[30] = true,
		[35] = true
	},
}

function Immobile:GetDuration(unit)
	local SpellCastTime = 0
	local AttackCastTime = 0
	local ImmobileDuration = 0
	local KnockDuration = 0
	local SlowDuration = 0

	local buffs = SDK.BuffManager:GetBuffs(unit)
	for i = 1, #buffs do
		local buff = buffs[i]
		local duration = buff.duration
		if duration > 0 then
			if duration > ImmobileDuration and self.IMMOBILE_TYPES[buff.type] then
				ImmobileDuration = duration
			elseif buff.type == 31 then
				KnockDuration = duration
			elseif buff.type == 11 then
				SlowDuration = duration
			end
		end
	end
	local spell = unit.activeSpell
	if spell and spell.valid then
		if spell.isAutoAttack then
			AttackCastTime = spell.castEndTime
		elseif spell.windup > 0.1 then
			SpellCastTime = spell.castEndTime
		end
	end
	return ImmobileDuration, SpellCastTime, AttackCastTime, KnockDuration, SlowDuration
end

Math = {}

function Math:Get2D(p)
	if p == nil then
		return { x = 0, z = 0 }
	end
	p = p.pos == nil and p or p.pos
	return { x = p.x, z = p.z == nil and p.y or p.z }
end

function Math:Get3D(p)
	p = p or { x = 0, y = 0, z = 0 }
	local result = Vector(p.x or 0, p.y or 0, p.z or p.y or 0)
	return result
end

function Math:GetDistance(p1, p2)
	if p1 == nil or p2 == nil then
		return math_huge
	end
	p1 = self:Get2D(p1)
	p2 = self:Get2D(p2)
	local dx = p2.x - p1.x
	local dz = p2.z - p1.z
	return math_sqrt(dx * dx + dz * dz)
end

function Math:GetDistanceSqr(p1, p2)
	if p1 == nil or p2 == nil then
		return math_huge
	end
	p1 = self:Get2D(p1)
	p2 = self:Get2D(p2)
	local dx = p2.x - p1.x
	local dz = p2.z - p1.z
	return dx * dx + dz * dz
end

function Math:IsInRange(p1, p2, range)
	if p1 == nil or p2 == nil then
		return false
	end
	p1 = self:Get2D(p1)
	p2 = self:Get2D(p2)
	local dx = p1.x - p2.x
	local dz = p1.z - p2.z
	if dx * dx + dz * dz <= range * range then
		return true
	end
	return false
end

function Math:VectorsEqual(p1, p2, num)
	num = num or 5
	if self:GetDistance(p1, p2) < num then
		return true
	end
	return false
end

function Math:Normalized(p1, p2)
	if p1 == nil or p2 == nil then
		return nil
	end
	local dx = p1.x - p2.x
	local dz = p1.z - p2.z
	local length = math_sqrt(dx * dx + dz * dz)
	local sol = nil
	if length > 0 then
		local inv = 1.0 / length
		sol = { x = (dx * inv), z = (dz * inv) }
	end
	return sol
end

function Math:Extended(vec, dir, range)
	if dir == nil then
		return vec
	end
	return { x = vec.x + dir.x * range, z = vec.z + dir.z * range }
end

function Math:ExtendTo(from, to, range)
	return self:Extended(from, self:Normalized(to, from), range)
end

function Math:Add(p1, p2)
	return { x = p1.x + p2.x, z = p1.z + p2.z }
end

function Math:Sub(p1, p2)
	return { x = p1.x - p2.x, z = p1.z - p2.z }
end

function Math:Mul(p, value)
	return { x = p.x * value, z = p.z * value }
end

function Math:Div(p, value)
	if value == 0 then
		return { x = 0, z = 0 }
	end
	return { x = p.x / value, z = p.z / value }
end

function Math:Dot(p1, p2)
	return p1.x * p2.x + p1.z * p2.z
end

function Math:Cross(p1, p2)
	return p1.x * p2.z - p1.z * p2.x
end

function Math:Rotate(p, angle)
	local rad = angle * math_pi / 180
	local c = math.cos(rad)
	local s = math.sin(rad)
	return { x = p.x * c - p.z * s, z = p.z * c + p.x * s }
end

function Math:DistanceToLineSegmentSqr(p, startPos, endPos)
	local pointLine, isOnSegment = self:ClosestPointOnLineSegment(p, startPos, endPos)
	return self:GetDistanceSqr(p, pointLine), isOnSegment, pointLine
end

function Math:ProjectOn(point, startPos, endPos)
	local ax = startPos.x
	local az = startPos.z
	local bx = endPos.x
	local bz = endPos.z
	local dx = bx - ax
	local dz = bz - az
	local len2 = dx * dx + dz * dz
	if len2 == 0 then
		return { LinePoint = startPos, IsOnSegment = false }
	end
	local t = ((point.x - ax) * dx + (point.z - az) * dz) / len2
	return {
		LinePoint = { x = ax + t * dx, z = az + t * dz },
		IsOnSegment = t >= 0 and t <= 1,
	}
end

function Math:Perpendicular(dir)
	if dir == nil then
		return nil
	end
	return { x = -dir.z, z = dir.x }
end

function Math:Intersection(s1, e1, s2, e2)
	local IntersectionResult = { Intersects = false, Point = { x = 0, z = 0 } }
	local deltaACz = s1.z - s2.z
	local deltaDCx = e2.x - s2.x
	local deltaACx = s1.x - s2.x
	local deltaDCz = e2.z - s2.z
	local deltaBAx = e1.x - s1.x
	local deltaBAz = e1.z - s1.z
	local denominator = deltaBAx * deltaDCz - deltaBAz * deltaDCx
	local numerator = deltaACz * deltaDCx - deltaACx * deltaDCz
	if denominator == 0 then
		if numerator == 0 then
			if s1.x >= s2.x and s1.x <= e2.x then
				return { Intersects = true, Point = s1 }
			end
			if s2.x >= s1.x and s2.x <= e1.x then
				return { Intersects = true, Point = s2 }
			end
			return IntersectionResult
		end
		return IntersectionResult
	end
	local r = numerator / denominator
	if r < 0 or r > 1 then
		return IntersectionResult
	end
	local s = (deltaACz * deltaBAx - deltaACx * deltaBAz) / denominator
	if s < 0 or s > 1 then
		return IntersectionResult
	end
	local point = { x = s1.x + r * deltaBAx, z = s1.z + r * deltaBAz }
	return { Intersects = true, Point = point }
end

function Math:ClosestPointOnLineSegment(p, p1, p2)
	if p == nil or p1 == nil or p2 == nil then
		return p1 or p2 or { x = 0, z = 0 }, false
	end
	local px = p.x
	local pz = p.z
	local ax = p1.x
	local az = p1.z
	local bx = p2.x
	local bz = p2.z
	local bxax = bx - ax
	local bzaz = bz - az
	local len2 = bxax * bxax + bzaz * bzaz
	if len2 == 0 then
		return p1, false
	end
	local t = ((px - ax) * bxax + (pz - az) * bzaz) / len2
	if t < 0 then
		return p1, false
	end
	if t > 1 then
		return p2, false
	end
	return { x = ax + t * bxax, z = az + t * bzaz }, true
end

function Math:Intercept(src, spos, epos, sspeed, tspeed)
	local dx = epos.x - spos.x
	local dz = epos.z - spos.z
	local magnitude = math_sqrt(dx * dx + dz * dz)
	if magnitude == 0 or tspeed == 0 or sspeed == 0 then
		return nil
	end
	local tx = spos.x - src.x
	local tz = spos.z - src.z
	local tvx = (dx / magnitude) * tspeed
	local tvz = (dz / magnitude) * tspeed
	local a = tvx * tvx + tvz * tvz - sspeed * sspeed
	local b = 2 * (tvx * tx + tvz * tz)
	local c = tx * tx + tz * tz
	local ts
	if math_abs(a) < 1e-6 then
		if math_abs(b) < 1e-6 then
			if math_abs(c) < 1e-6 then
				ts = { 0, 0 }
			end
		else
			ts = { -c / b, -c / b }
		end
	else
		local disc = b * b - 4 * a * c
		if disc >= 0 then
			disc = math_sqrt(disc)
			local a = 2 * a
			ts = { (-b - disc) / a, (-b + disc) / a }
		end
	end
	local sol
	if ts then
		local t0 = ts[1]
		local t1 = ts[2]
		local t = math_min(t0, t1)
		if t < 0 then
			t = math_max(t0, t1)
		end
		if t > 0 then
			sol = t
		end
	end
	return sol
end

function Math:VectorMovementCollision(startPoint1, endPoint1, v1, startPoint2, v2, delay)
	local sP1x = startPoint1.x
	local sP1y = startPoint1.z
	local eP1x = endPoint1.x
	local eP1y = endPoint1.z
	local sP2x = startPoint2.x
	local sP2y = startPoint2.z
	local d = eP1x - sP1x
	local e = eP1y - sP1y
	local dist = math_sqrt(d * d + e * e)
	if dist == 0 then
		return nil, nil
	end
	local t1
	local s = math_abs(dist) > 0 and v1 * d / dist or 0
	local k = math_abs(dist) > 0 and v1 * e / dist or 0
	local r = sP2x - sP1x
	local j = sP2y - sP1y
	local c = r * r + j * j
	if dist > 0 then
		if v1 == math_huge then
			t1 = dist / v1
		elseif v2 == math_huge then
			t1 = 0
		else
			local a = s * s + k * k - v2 * v2
			local b = -r * s - j * k
			if a == 0 then
				if b == 0 then
					t1 = c == 0 and 0 or nil
				else
					local t = -c / (2 * b)
					t1 = v2 * t >= 0 and t or nil
				end
			else
				local sqr = b * b - a * c
				if sqr >= 0 then
					local nom = math_sqrt(sqr)
					local t = (-nom - b) / a
					t1 = v2 * t >= 0 and t or nil
					t = (nom - b) / a
					if v2 * t >= 0 and (t1 == nil or t < t1) then
						t1 = t
					end
				end
			end
		end
	end
	if t1 == nil then
		return nil, nil
	end
	local t2 = t1 + (delay or 0)
	local pos = { x = sP1x + s * t2, z = sP1y + k * t2 }
	return t1, pos
end

function Math:Polar(p1)
	local x = p1.x
	local z = p1.z
	if x == 0 then
		if z > 0 then
			return 90
		end
		if z < 0 then
			return 270
		end
		return 0
	end
	local theta = math_atan(z / x) * (180.0 / math_pi) --RadianToDegree
	if x < 0 then
		theta = theta + 180
	end
	if theta < 0 then
		theta = theta + 360
	end
	return theta
end

function Math:AngleBetween(p1, p2)
	if p1 == nil or p2 == nil then
		return nil
	end
	local theta = self:Polar(p1) - self:Polar(p2)
	if theta < 0 then
		theta = theta + 360
	end
	if theta > 180 then
		theta = 360 - theta
	end
	return theta
end

function Math:FindAngle(p1, center, p2)
	local b = math_pow(center.x - p1.x, 2) + math_pow(center.z - p1.z, 2)
	local a = math_pow(center.x - p2.x, 2) + math_pow(center.z - p2.z, 2)
	local c = math_pow(p2.x - p1.x, 2) + math_pow(p2.z - p1.z, 2)
	local angle = math_acos((a + b - c) / math_sqrt(4 * a * b)) * (180 / math_pi)
	if angle > 90 then
		angle = 180 - angle
	end
	return angle
end

function Math:CircleCircleIntersection(center1, center2, radius1, radius2)
	local result = {}
	local D = self:GetDistance(center1, center2)
	if D > radius1 + radius2 or D <= math_abs(radius1 - radius2) then
		return result
	end
	local A = (radius1 * radius1 - radius2 * radius2 + D * D) / (2 * D)
	local H = math_sqrt(radius1 * radius1 - A * A)
	local Direction = self:Normalized(center2, center1)
	local PA = self:Extended(center1, Direction, A)
	local DirectionPerpendicular = self:Perpendicular(Direction)
	table_insert(result, self:Extended(PA, DirectionPerpendicular, H))
	table_insert(result, self:Extended(PA, DirectionPerpendicular, -H))
	return result
end

function Math:GetMEC(points)
	local count = #points
	if count == 0 then
		return { Center = { x = 0, z = 0 }, Radius = 0 }
	end
	if count == 1 then
		return { Center = points[1], Radius = 0 }
	end
	local best = { Center = points[1], Radius = math_huge }
	local function contains(circle)
		for i = 1, count do
			if Math:GetDistance(circle.Center, points[i]) > circle.Radius + 1e-4 then
				return false
			end
		end
		return true
	end
	for i = 1, count do
		for j = i + 1, count do
			local center = Math:Div(Math:Add(points[i], points[j]), 2)
			local circle = { Center = center, Radius = Math:GetDistance(points[i], points[j]) / 2 }
			if circle.Radius < best.Radius and contains(circle) then
				best = circle
			end
		end
	end
	for i = 1, count do
		for j = i + 1, count do
			for k = j + 1, count do
				local ax, az = points[i].x, points[i].z
				local bx, bz = points[j].x, points[j].z
				local cx, cz = points[k].x, points[k].z
				local d = 2 * (ax * (bz - cz) + bx * (cz - az) + cx * (az - bz))
				if math_abs(d) > 1e-6 then
					local ux = ((ax * ax + az * az) * (bz - cz) + (bx * bx + bz * bz) * (cz - az) + (cx * cx + cz * cz) * (az - bz)) / d
					local uz = ((ax * ax + az * az) * (cx - bx) + (bx * bx + bz * bz) * (ax - cx) + (cx * cx + cz * cz) * (bx - ax)) / d
					local center = { x = ux, z = uz }
					local circle = { Center = center, Radius = Math:GetDistance(center, points[i]) }
					if circle.Radius < best.Radius and contains(circle) then
						best = circle
					end
				end
			end
		end
	end
	if best.Radius == math_huge then
		best = { Center = points[1], Radius = 0 }
	end
	return best
end
Path = {}

function Path:GetLenght(path)
	local result = 0
	if path == nil then
		return result
	end
	for i = 1, #path - 1 do
		result = result + Math:GetDistance(path[i], path[i + 1])
	end
	return result
end

function Path:GetLength(path)
	return self:GetLenght(path)
end

function Path:CutPath(path, distance)
	local result = {}
	if distance <= 0 then
		return path
	end
	for i = 1, #path - 1 do
		local a, b = path[i], path[i + 1]
		local dist = Math:GetDistance(a, b)
		if dist > distance then
			table_insert(result, Math:Extended(a, Math:Normalized(b, a), distance))
			for j = i + 1, #path do
				table_insert(result, path[j])
			end
			break
		end
		distance = distance - dist
	end
	return #result > 0 and result or { path[#path] }
end

function Path:ReversePath(path)
	local result = {}
	for i = #path, 1, -1 do
		table_insert(result, path[i])
	end
	return result
end

function Path:GetPath(unit)
	local result = { Math:Get2D(unit.pos) }
	local path = unit.pathing
	if path then
		if path.isDashing then
			local endPos = path.endPos
			if endPos and endPos.x then
				table_insert(result, Math:Get2D(endPos))
			else
				--print("GetPath -> endPos=" .. tostring(endPos))
			end
		else
			local istart = path.pathIndex
			local iend = path.pathCount
			if istart and iend and istart >= 0 and iend <= 20 then
				for i = istart, iend do
					local pos = unit:GetPath(i)
					if pos and pos.x then
						table_insert(result, Math:Get2D(pos))
					else
						--print("GetPath -> pos=" .. tostring(pos))
					end
				end
			else
				--print("GetPath -> istart=" .. tostring(istart) .. " iend=" .. tostring(iend))
			end
		end
	end
	return result
end

function Path:GetPredictedPath(source, speed, movespeed, path)
	local result = {}
	local tT = 0
	for i = 1, #path - 1 do
		local a = path[i]
		table_insert(result, a)
		local b = path[i + 1]
		local tB = Math:GetDistance(a, b) / movespeed
		local direction = Math:Normalized(b, a)
		a = Math:Extended(a, direction, -(movespeed * tT))
		local t = Math:Intercept(source, a, b, speed, movespeed)
		if t and t >= tT and t <= tT + tB then
			table_insert(result, Math:Extended(a, direction, t * movespeed))
			return result, t
		end
		tT = tT + tB
	end
	return nil, -1
end

function Path:GetPositionOnPath(input, path, speed)
	speed = speed or Prediction:SpeedFromVelocity(input.Unit)
	local pLength = self:GetLenght(path)
	if pLength < 5 then
		local pos = Math:Get2D(input.Unit.pos)
		return Prediction:CreateOutput(input, HITCHANCE_HIGH, pos, pos)
	end
	local tDistance = input.Delay * speed - input.RealRadius
	if pLength >= tDistance and input.Speed == math_huge then
		for i = 1, #path - 1 do
			local a = path[i]
			local b = path[i + 1]
			local d = Math:GetDistance(a, b)
			if d >= tDistance then
				local direction = Math:Normalized(b, a)
				local cp = Math:Extended(a, direction, tDistance)
				local p = Math:Extended(a, direction, i == #path - 1 and math_min(tDistance + input.RealRadius, d) or tDistance + input.RealRadius)
				return Prediction:CreateOutput(input, HITCHANCE_HIGH, cp, p)
			end
			tDistance = tDistance - d
		end
	end
	if pLength >= tDistance and input.Speed ~= math_huge then
		local d = tDistance
		if input.Type == SPELLTYPE_LINE or input.Type == SPELLTYPE_CONE then
			if Math:GetDistanceSqr(input.From, Math:Get2D(input.Unit.pos)) < 200 * 200 then
				d = input.Delay * speed
			end
		end
		path = self:CutPath(path, d)
		local tT = 0
		for i = 1, #path - 1 do
			local a = path[i]
			local b = path[i + 1]
			local tB = Math:GetDistance(a, b) / speed
			local direction = Math:Normalized(b, a)
			a = Math:Extended(a, direction, -speed * tT)
			local t, pos = Math:VectorMovementCollision(a, b, speed, input.From, input.Speed, tT)
			if pos and t and t >= tT and t <= tT + tB then
				if Math:GetDistanceSqr(pos, b) < 20 then
					break
				end
				local p = Math:Extended(pos, direction, input.RealRadius)
				return Prediction:CreateOutput(input, HITCHANCE_HIGH, pos, p)
			end
			tT = tT + tB
		end
	end
	local position = path[#path]
	return Prediction:CreateOutput(input, HITCHANCE_NORMAL, position, position)
end
UnitData = {
	Visible = {},
	Waypoints = {},
	PathBank = {},
	StoredPaths = {},
	SpellState = {},
	SpecialSpells = {
		katarinar = 1,
		drain = 1,
		crowstorm = 1,
		consume = 0.5,
		absolutezero = 1,
		staticfield = 0.5,
		cassiopeiapetrifyinggaze = 0.5,
		ezrealtrueshotbarrage = 1,
		galioidolofdurand = 1,
		luxmalicecannon = 1,
		reapthewhirlwind = 1,
		jinxw = 0.6,
		jinxr = 0.6,
		missfortunebullettime = 1,
		shenstandunited = 1,
		threshe = 0.4,
		threshrpenta = 0.75,
		threshq = 0.75,
		infiniteduress = 1,
		meditate = 1,
		alzaharnethergrasp = 1,
		lucianq = 0.5,
		caitlynpiltoverpeacemaker = 0.5,
		velkozr = 0.5,
		jhinr = 2,
	},
}

function UnitData:OnVisible(id, visible)
	if self.Visible[id] == nil then
		self.Visible[id] = { visible = visible, visibleTick = GetTickCount(), invisibleTick = GetTickCount() }
	end
	if visible then
		if not self.Visible[id].visible then
			self.Visible[id].visible = true
			self.Visible[id].visibleTick = GetTickCount()
		end
	else
		if self.Visible[id].visible then
			self.Visible[id].visible = false
			self.Visible[id].invisibleTick = GetTickCount()
		end
	end
end

function UnitData:OnWaypoint(id, path, hasMovePath, isDashing, endPos)
	local timer = GetTickCount()
	if self.Waypoints[id] == nil then
		self.Waypoints[id] = {
			moving = hasMovePath,
			dashing = isDashing,
			path = path,
			tick = timer,
			stoptick = timer,
			pos = endPos,
			clickAverageTime = 0,
			newPathTick = timer,
			stopMoveTick = timer,
		}
	end
	if hasMovePath then
		if not Math:VectorsEqual(self.Waypoints[id].pos, endPos, 50) then
			self.Waypoints[id].tick = timer
			self.Waypoints[id].newPathTick = timer
			self:AddPathBank(id, path, timer)
		end
		self.Waypoints[id].pos = endPos
		self.Waypoints[id].dashing = isDashing
	elseif self.Waypoints[id].moving then
		self.Waypoints[id].stoptick = GetTickCount()
		self.Waypoints[id].stopMoveTick = timer
		self:AddPathBank(id, path, timer)
	end
	self.Waypoints[id].path = path
	self.Waypoints[id].moving = hasMovePath
	self:AddStoredPath(id, path, timer)
end

function UnitData:AddPathBank(id, path, timer)
	if path == nil or #path == 0 then
		return
	end
	self.PathBank[id] = self.PathBank[id] or {}
	local bank = self.PathBank[id]
	local last = bank[#bank]
	if last and Math:VectorsEqual(last.Position[#last.Position], path[#path], 5) and timer - last.Time < 30 then
		return
	end
	table_insert(bank, { Position = path, Time = timer })
	if #bank > 3 then
		table_remove(bank, 1)
	end
	local wp = self.Waypoints[id]
	if wp and #bank >= 3 then
		local time0 = timer - bank[#bank].Time
		local time1 = bank[#bank].Time - bank[#bank - 1].Time
		local time2 = bank[#bank - 1].Time - bank[#bank - 2].Time
		local sum, count = 0, 1
		if time0 < 400 and #path > 1 then
			sum = sum + time0
			count = count + 1
		end
		if time1 < 400 and #(bank[#bank].Position) > 1 then
			sum = sum + time1
			count = count + 1
		end
		if time2 < 400 and #(bank[#bank - 1].Position) > 1 then
			sum = sum + time2
			count = count + 1
		end
		wp.clickAverageTime = (wp.clickAverageTime + sum) / count
	end
end

function UnitData:AddStoredPath(id, path, timer)
	if path == nil or #path == 0 then
		return
	end
	self.StoredPaths[id] = self.StoredPaths[id] or {}
	local stored = self.StoredPaths[id]
	local last = stored[#stored]
	if last and Math:VectorsEqual(last.EndPoint, path[#path], 5) and timer - last.Tick < 30 then
		return
	end
	table_insert(stored, { Path = path, Tick = timer, EndPoint = path[#path], StartPoint = path[1] })
	if #stored > 50 then
		for i = 1, 40 do
			table_remove(stored, 1)
		end
	end
end

function UnitData:OnSpell(unit)
	local id = unit.networkID
	local timer = GetTickCount()
	self.SpellState[id] = self.SpellState[id]
		or { aaTick = timer, specialSpellFinishTick = timer, lastSpellName = nil, lastSpellStart = 0 }
	local state = self.SpellState[id]
	local spell = unit.activeSpell
	if not spell or not spell.valid then
		return
	end
	local spellName = (spell.name or ""):lower()
	local spellStart = spell.startTime or spell.castEndTime or 0
	if state.lastSpellName == spellName and state.lastSpellStart == spellStart then
		return
	end
	state.lastSpellName = spellName
	state.lastSpellStart = spellStart
	if spell.isAutoAttack then
		state.aaTick = timer
		return
	end
	local duration = self.SpecialSpells[spellName]
	if duration then
		state.specialSpellFinishTick = timer + duration * 1000
	elseif (spell.windup and spell.windup > 0.1) or unit.isChanneling then
		state.specialSpellFinishTick = timer + 100
	end
end

function UnitData:OnTick()
	local id, visible, path, pathing, hasMovePath, isDashing, endPos
	for i, unit in ipairs(ObjectManager:GetHeroes()) do
		id = unit.networkID
		visible = unit.visible
		self:OnVisible(id, visible)
		if visible then
			pathing = unit.pathing
			if pathing then
				hasMovePath = pathing.hasMovePath
				isDashing = pathing.isDashing
				endPos = Math:Get2D(pathing.endPos)
				path = Path:GetPath(unit)
				self:OnWaypoint(id, path, hasMovePath, isDashing, endPos)
			end
			self:OnSpell(unit)
		end
	end
end

function UnitData:OnPrediction(unit)
	local id = unit.networkID
	local visible = unit.visible
	self:OnVisible(id, visible)
	if visible then
		local hasMovePath = unit.pathing.hasMovePath
		local isDashing = unit.pathing.isDashing
		local endPos = Math:Get2D(unit.pathing.endPos)
		self:OnWaypoint(id, Path:GetPath(unit), hasMovePath, isDashing, endPos)
		self:OnSpell(unit)
	end
end

function UnitData:GetWaypoint(unit)
	return self.Waypoints[unit.networkID]
end

function UnitData:GetPathBank(unit)
	return self.PathBank[unit.networkID] or {}
end

function UnitData:GetStoredPaths(unit, maxT)
	local result = {}
	local timer = GetTickCount()
	local stored = self.StoredPaths[unit.networkID] or {}
	for i = 1, #stored do
		if (timer - stored[i].Tick) / 1000 < maxT then
			table_insert(result, stored[i])
		end
	end
	return result
end

function UnitData:GetMeanSpeed(unit, maxT)
	local paths = self:GetStoredPaths(unit, maxT or 1.5)
	local distance = 0
	if #paths == 0 then
		return unit.ms
	end
	local timer = GetTickCount()
	distance = distance + ((maxT or 1.5) - ((timer - paths[1].Tick) / 1000)) * unit.ms
	for i = 1, #paths - 1 do
		local currentPath = paths[i]
		local nextPath = paths[i + 1]
		if #currentPath.Path > 0 then
			distance = distance + math_min(((currentPath.Tick - nextPath.Tick) / 1000) * unit.ms, Path:GetLenght(currentPath.Path))
		end
	end
	local lastPath = paths[#paths]
	if lastPath and #lastPath.Path > 0 then
		distance = distance + math_min(((timer - lastPath.Tick) / 1000) * unit.ms, Path:GetLenght(lastPath.Path))
	end
	return distance / (maxT or 1.5)
end

function UnitData:GetTendency(unit)
	local paths = self:GetStoredPaths(unit, 1.5)
	local result = { x = 0, z = 0 }
	if #paths == 0 then
		return result
	end
	local unitPos = Math:Get2D(unit.pos)
	for i = 1, #paths do
		local dir = Math:Normalized(paths[i].EndPoint, unitPos)
		if dir then
			result = Math:Add(result, dir)
		end
	end
	return Math:Div(result, #paths)
end

function UnitData:GetSpecialSpellEndTime(unit)
	local state = self.SpellState[unit.networkID]
	return state and state.specialSpellFinishTick - GetTickCount() or 0
end

function UnitData:GetLastAutoAttackTime(unit)
	local state = self.SpellState[unit.networkID]
	return state and GetTickCount() - state.aaTick or math_huge
end

function UnitData:GetLastNewPathTime(unit)
	local wp = self:GetWaypoint(unit)
	return wp and GetTickCount() - wp.newPathTick or math_huge
end

function UnitData:GetLastVisableTime(unit)
	local vis = self.Visible[unit.networkID]
	return vis and GetTickCount() - vis.visibleTick or math_huge
end

function UnitData:GetLastStopMoveTime(unit)
	local wp = self:GetWaypoint(unit)
	return wp and GetTickCount() - wp.stopMoveTick or math_huge
end

function UnitData:IsSpamClick(unit, radius, delay)
	local bank = self:GetPathBank(unit)
	if #bank < 3 then
		return false
	end
	if #(bank[1].Position) < 2 or #(bank[2].Position) < 2 or #(bank[3].Position) < 2 then
		return false
	end
	local fixDelay = radius * 2 - Prediction:SpeedFromVelocity(unit) * delay
	local timer = GetTickCount()
	if timer - bank[3].Time > 100 then
		return false
	end
	if timer - bank[1].Time > 900 + fixDelay then
		return false
	end
	local pos1 = Math:Sub(bank[1].Position[#bank[1].Position], bank[1].Position[1])
	local pos2 = Math:Sub(bank[2].Position[#bank[2].Position], bank[2].Position[1])
	local pos3 = Math:Sub(bank[3].Position[#bank[3].Position], bank[3].Position[1])
	local angle1 = Math:AngleBetween(pos1, pos2)
	local angle2 = Math:AngleBetween(pos2, pos3)
	return angle1 and angle2 and angle1 > 130 and angle2 > 130
end

Callback.Add("Load", function()
	-- Yasuo detection
	if _G.SDK and _G.SDK.ObjectManager and _G.SDK.ObjectManager.OnEnemyHeroLoad then
		_G.SDK.ObjectManager:OnEnemyHeroLoad(function(args)
			YasuoWall:OnEnemyHeroLoad(args)
		end)
	end
	Callback.Add("Tick", function()
		UnitData:OnTick()
		YasuoWall:OnTick()
	end)
end)
ObjectManager = {}

function ObjectManager:IsValid(unit)
	if unit and unit.valid and unit.visible and not unit.dead and unit.isTargetable then
		return true
	end
	return false
end

function ObjectManager:GetHeroes()
	local _Heroes = {}
	local hero, count
	count = Game.HeroCount()
	for i = 1, count do
		hero = Game.Hero(i)
		if hero and hero.valid and not hero.dead then
			table_insert(_Heroes, hero)
		end
	end
	return _Heroes
end

function ObjectManager:GetEnemyHeroes()
	local _EnemyHeroes = {}
	local count = Game.HeroCount()
	for i = 1, count do
		local hero = Game.Hero(i)
		if self:IsValid(hero) and hero.isEnemy then
			table_insert(_EnemyHeroes, hero)
		end
	end
	return _EnemyHeroes
end

function ObjectManager:GetAllyHeroes()
	local _AllyHeroes = {}
	local count = Game.HeroCount()
	for i = 1, count do
		local hero = Game.Hero(i)
		if self:IsValid(hero) and hero.isAlly then
			table_insert(_AllyHeroes, hero)
		end
	end
	return _AllyHeroes
end

function ObjectManager:GetTurrets()
	local turrets = {}
	if Game.TurretCount and Game.Turret then
		for i = 1, Game.TurretCount() do
			local turret = Game.Turret(i)
			if turret and turret.valid and not turret.dead then
				table_insert(turrets, turret)
			end
		end
	end
	return turrets
end

Collision = {}

function Collision:GetCollision(source, castPos, speed, delay, radius, collisionTypes, skipID, input)
	collisionTypes = collisionTypes or { COLLISION_MINION, COLLISION_YASUOWALL }
	source = Math:Extended(source, Math:Normalized(source, castPos), 75)
	castPos = Math:Extended(castPos, Math:Normalized(castPos, source), 75)
	local isWall, collisionObjects, collisionCount = false, {}, 0
	local objects = {}
	local checkYasuoWall = false
	for i, colType in pairs(collisionTypes) do
		if colType == COLLISION_YASUOWALL then
			if YasuoWall.HasYasuo then
				checkYasuoWall = true
			end
		elseif colType == COLLISION_MINION then
			for k = 1, Game.MinionCount() do
				local unit = Game.Minion(k)
				if
					unit.networkID ~= skipID
					and ObjectManager:IsValid(unit)
					and unit.isEnemy
					and Math:GetDistance(source, Math:Get2D(unit.pos)) < 2000
				then
					table_insert(objects, unit)
				end
			end
		elseif colType == COLLISION_ALLYHERO then
			for k, unit in pairs(ObjectManager:GetAllyHeroes()) do
				if unit.networkID ~= skipID and Math:GetDistance(source, Math:Get2D(unit.pos)) < 2000 then
					table_insert(objects, unit)
				end
			end
		elseif colType == COLLISION_ENEMYHERO then
			for k, unit in pairs(ObjectManager:GetEnemyHeroes()) do
				if unit.networkID ~= skipID and Math:GetDistance(source, Math:Get2D(unit.pos)) < 2000 then
					table_insert(objects, unit)
				end
			end
		end
	end
	for i, object in pairs(objects) do
		local isCol = false
		local objectPos = Math:Get2D(object.pos)
		local objectRadius = object.boundingRadius or 0
		if input then
			local bOffset = objectRadius + ((input.Unit and input.Unit.boundingRadius) or 0)
			if object.pathing and object.pathing.hasMovePath then
				bOffset = bOffset + 10
			end
			if Math:GetDistance(objectPos, source) < bOffset + 30 or Math:GetDistance(objectPos, castPos) < bOffset then
				isCol = true
			end
		end
		local pointLine, isOnSegment = Math:ClosestPointOnLineSegment(objectPos, source, castPos)
		if isOnSegment and Math:IsInRange(objectPos, pointLine, radius + 15 + objectRadius) then
			isCol = true
		elseif object.pathing.hasMovePath then
			if input then
				local predInput = Prediction:CreateInput({
					Unit = object,
					From = source,
					RangeCheckFrom = source,
					Speed = speed,
					Delay = delay,
					Radius = radius,
					Range = input.Range or math_huge,
					Type = input.Type or SPELLTYPE_LINE,
					UseBoundingRadius = false,
				})
				local pred = Prediction:GetPredictionOutput(predInput, false, false)
				objectPos = pred.UnitPosition or objectPos
			else
				objectPos = Math:Get2D(object:GetPrediction(speed, delay))
			end
			pointLine, isOnSegment = Math:ClosestPointOnLineSegment(objectPos, source, castPos)
			if isOnSegment and Math:IsInRange(objectPos, pointLine, radius + 15 + objectRadius) then
				isCol = true
			end
		end
		if isCol then
			table_insert(collisionObjects, object)
			collisionCount = collisionCount + 1
		end
	end
	-- Check Yasuo wall collision
	if checkYasuoWall then
		isWall = YasuoWall:CheckCollision(source, castPos)
	end
	return isWall, collisionObjects, collisionCount
end
Prediction = {}

function Prediction:CreateInput(args)
	args = args or {}
	local unit = args.Unit or args.Target or args.target
	local from = Math:Get2D(args.From or args.Source or args.source or myHero.pos)
	local rangeCheckFrom = Math:Get2D(args.RangeCheckFrom or from)
	local radius = args.Radius or 1
	local useBoundingRadius = args.UseBoundingRadius
	if useBoundingRadius == nil then
		useBoundingRadius = true
	end
	local input = {
		Aoe = args.Aoe or false,
		Collision = args.Collision or false,
		CollisionObjects = args.CollisionObjects or args.CollisionTypes or { COLLISION_MINION, COLLISION_YASUOWALL },
		Delay = args.Delay or 0,
		Radius = radius,
		Range = args.Range or math_huge,
		Speed = args.Speed or math_huge,
		Type = args.Type or SPELLTYPE_LINE,
		Unit = unit,
		UseBoundingRadius = useBoundingRadius,
		From = from,
		RangeCheckFrom = rangeCheckFrom,
	}
	input.RealRadius = useBoundingRadius and unit and radius + (unit.boundingRadius or 0) or radius
	return input
end

function Prediction:CreateOutput(input, hitchance, castPosition, unitPosition)
	return {
		Input = input,
		Hitchance = hitchance or HITCHANCE_IMPOSSIBLE,
		CastPosition = castPosition,
		UnitPosition = unitPosition,
		AoeTargetsHit = {},
		AoeTargetsHitCount = 0,
		CollisionObjects = {},
		TimeToHit = input and castPosition and input.Speed ~= math_huge and input.Delay + Math:GetDistance(input.From, castPosition) / input.Speed or (input and input.Delay or 0),
	}
end

function Prediction:SpeedFromVelocity(unit)
	if not unit then
		return 0
	end
	if unit.pathing and unit.pathing.isDashing then
		return unit.ms
	end
	if unit.type ~= Obj_AI_Hero then
		return unit.ms
	end
	local dir = unit.dir
	if dir and (dir.x ~= 0 or dir.z ~= 0) then
		return unit.ms
	end
	return unit.ms
end

function Prediction:GetDashingPrediction(input)
	local pathing = input.Unit.pathing
	local result = self:CreateOutput(input, HITCHANCE_IMPOSSIBLE, nil, nil)
	if pathing and pathing.isDashing then
		local endP = Math:Get2D(pathing.endPos or input.Unit.posTo)
		local dashSpeed = pathing.dashSpeed and pathing.dashSpeed > 0 and pathing.dashSpeed or input.Unit.ms
		local dashPred = Path:GetPositionOnPath(input, { Math:Get2D(input.Unit.pos), endP }, dashSpeed)
		if dashPred.Hitchance >= HITCHANCE_HIGH and Math:GetDistanceSqr(dashPred.UnitPosition, endP) < 200 * 200 then
			dashPred.CastPosition = dashPred.UnitPosition
			dashPred.Hitchance = HITCHANCE_DASHING
			return dashPred
		end
		local pathLength = Path:GetLenght({ Math:Get2D(input.Unit.pos), endP })
		if pathLength > 200 then
			local timeToPoint = input.Delay / 2 + Math:GetDistance(input.From, endP) / input.Speed - 0.25
			if timeToPoint <= Math:GetDistance(Math:Get2D(input.Unit.pos), endP) / dashSpeed + input.RealRadius / input.Unit.ms then
				return self:CreateOutput(input, HITCHANCE_DASHING, endP, endP)
			end
		end
		result.CastPosition = endP
		result.UnitPosition = endP
	end
	return result
end

function Prediction:GetImmobilePrediction(input, remainingImmobileT)
	local speedTime = input.Speed == math_huge and 0 or Math:GetDistance(input.Unit.pos, input.From) / input.Speed
	local timeToReachTargetPosition = input.Delay + speedTime
	if timeToReachTargetPosition <= remainingImmobileT + input.RealRadius / input.Unit.ms then
		local pos = Math:Get2D(input.Unit.pos)
		return self:CreateOutput(input, HITCHANCE_IMMOBILE, pos, pos)
	end
	local pos = Math:Get2D(input.Unit.pos)
	return self:CreateOutput(input, HITCHANCE_HIGH, pos, pos)
end

function Prediction:UnitIsImmobileUntil(unit)
	local duration = Immobile:GetDuration(unit)
	if duration and duration > 0 then
		return duration
	end
	return -1
end

function Prediction:UnitIsSlowed(unit)
	local _, _, _, _, slowDuration = Immobile:GetDuration(unit)
	return slowDuration or 0
end

function Prediction:IsMovingInSameDirection(source, target)
	local sourcePath = Path:GetPath(source)
	local targetPath = Path:GetPath(target)
	local sourceLW = sourcePath[#sourcePath]
	local targetLW = targetPath[#targetPath]
	if not source.pathing.hasMovePath or Math:VectorsEqual(sourceLW, Math:Get2D(source.pos), 5) then
		return false
	end
	if not target.pathing.hasMovePath or Math:VectorsEqual(targetLW, Math:Get2D(target.pos), 5) then
		return false
	end
	local pos1 = Math:Sub(sourceLW, Math:Get2D(source.pos))
	local pos2 = Math:Sub(targetLW, Math:Get2D(target.pos))
	local angle = Math:AngleBetween(pos1, pos2)
	return angle and angle < 20 or false
end

function Prediction:GetStandardPrediction(input)
	local speed = input.Unit.ms
	if input.Unit.type == Obj_AI_Hero then
		speed = self:SpeedFromVelocity(input.Unit)
		if Math:GetDistanceSqr(input.Unit.pos, input.From) < 230 * 230 then
			input.Delay = input.Delay / 2
			speed = speed / 1.5
		end
	end
	return Path:GetPositionOnPath(input, Path:GetPath(input.Unit), speed)
end

function Prediction:WayPointAnalysis(result, input)
	if not input.Unit or input.Unit.type ~= Obj_AI_Hero or input.Radius == 1 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	local wp = UnitData:GetWaypoint(input.Unit)
	if not wp then
		result.Hitchance = HITCHANCE_HIGH
		return result
	end
	if UnitData:GetSpecialSpellEndTime(input.Unit) > 100 or UnitData:GetLastStopMoveTime(input.Unit) < 100 and self:UnitIsImmobileUntil(input.Unit) > 0 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		result.CastPosition = Math:Get2D(input.Unit.pos)
		return result
	end
	local wayPoints = Path:GetPath(input.Unit)
	local lastWaypoint = wayPoints[#wayPoints] or Math:Get2D(input.Unit.pos)
	if not input.Unit.pathing.hasMovePath then
		lastWaypoint = Math:Get2D(input.Unit.pos)
	end
	local unitPos = Math:Get2D(input.Unit.pos)
	local distanceUnitToWaypoint = Math:GetDistance(lastWaypoint, unitPos)
	local distanceFromToUnit = Math:GetDistance(input.From, unitPos)
	local distanceFromToWaypoint = Math:GetDistance(lastWaypoint, input.From)
	local speedDelay = input.Speed == math_huge and 0 or distanceFromToUnit / input.Speed
	local velocity = self:SpeedFromVelocity(input.Unit)
	local totalDelay = speedDelay + input.Delay - input.Radius / velocity
	local moveArea = velocity * totalDelay
	local fixRange = moveArea * 0.25
	local lastNewPathTime = UnitData:GetLastNewPathTime(input.Unit)
	local pos1 = Math:Sub(lastWaypoint, unitPos)
	local pos2 = Math:Sub(input.From, unitPos)
	local angle = Math:AngleBetween(pos1, pos2) or 180
	if UnitData:GetLastVisableTime(input.Unit) < 100 or #wayPoints == 0 then
		result.Hitchance = HITCHANCE_NORMAL
		return result
	end
	if distanceFromToUnit > input.Range - fixRange and input.Type ~= SPELLTYPE_CIRCLE then
		if #wayPoints <= 1 or angle < 150 then
			result.Hitchance = HITCHANCE_NORMAL
			return result
		end
	end
	if UnitData:IsSpamClick(input.Unit, input.Radius, input.Delay) then
		result.Hitchance = HITCHANCE_VERY_HIGH
		result.CastPosition = unitPos
		return result
	end
	if distanceUnitToWaypoint > 0 and distanceUnitToWaypoint < 200 then
		result.Hitchance = HITCHANCE_NORMAL
		return result
	end
	if input.Unit.health and myHero.maxHealth and input.Unit.health < myHero.maxHealth * 0.2 + (myHero.totalDamage or 0) + (myHero.ap or 0) then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if myHero.health and myHero.maxHealth and myHero.health / myHero.maxHealth * 100 < 20 then
		result.Hitchance = HITCHANCE_VERY_HIGH
	end
	if distanceFromToUnit < 250 or distanceFromToWaypoint < 250 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	local remainingSlowT = self:UnitIsSlowed(input.Unit)
	if remainingSlowT > 0 then
		local travel = input.Speed == math_huge and 0 or Math:GetDistance(input.Unit.pos, input.From) / input.Speed
		if input.Delay + travel <= remainingSlowT + input.RealRadius / velocity then
			result.Hitchance = HITCHANCE_VERY_HIGH
		else
			result.Hitchance = HITCHANCE_HIGH
		end
		return result
	end
	if #wayPoints <= 1 or not input.Unit.pathing.hasMovePath then
		local stopTime = UnitData:GetLastStopMoveTime(input.Unit)
		local spell = input.Unit.activeSpell
		if stopTime < 1000 then
			if spell and spell.valid and spell.windup and totalDelay < (spell.castEndTime - Game.Timer()) and spell.windup > 0.1 then
				result.Hitchance = HITCHANCE_VERY_HIGH
			elseif spell and spell.valid and not spell.isAutoAttack and spell.castEndTime - Game.Timer() < 0.1 then
				result.Hitchance = HITCHANCE_NORMAL
			elseif UnitData:GetLastAutoAttackTime(input.Unit) < 60 and input.Delay < 0.3 then
				result.Hitchance = HITCHANCE_VERY_HIGH
			else
				result.Hitchance = HITCHANCE_NORMAL
			end
			return result
		end
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if distanceUnitToWaypoint > 1200 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if angle > 105 and angle < 150 and distanceUnitToWaypoint < 600 then
		result.Hitchance = HITCHANCE_NORMAL
		return result
	end
	if distanceUnitToWaypoint > 500 and (angle > 170 or angle < 10) then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if input.Radius >= 90 and input.Speed > 3000 and input.Delay < 0.7 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if distanceUnitToWaypoint > 500 then
		local turrets = ObjectManager:GetTurrets()
		for i = 1, #turrets do
			local turret = turrets[i]
			if turret.team == input.Unit.team and Math:GetDistance(turret.pos, input.From) < 2500 and Math:GetDistance(turret.pos, unitPos) > 400 then
				local pos3 = Math:Sub(Math:Get2D(turret.pos), unitPos)
				local angle2 = Math:AngleBetween(pos1, pos3)
				if angle2 and angle2 < 10 then
					result.Hitchance = HITCHANCE_VERY_HIGH
					return result
				end
			end
		end
	end
	local inSameDirection = self:IsMovingInSameDirection(input.Unit, myHero)
	if (inSameDirection or distanceUnitToWaypoint > 600) and (angle > 130 or angle < 15) then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	if #wayPoints == 2 and lastNewPathTime < 80 and totalDelay < 0.25 then
		result.Hitchance = HITCHANCE_VERY_HIGH
		return result
	end
	result.Hitchance = HITCHANCE_HIGH
	return result
end

function Prediction:GetPredictionOutput(input, ft, checkCollision)
	ft = ft ~= false
	checkCollision = checkCollision ~= false
	if not input or not ObjectManager:IsValid(input.Unit) then
		return self:CreateOutput(input, HITCHANCE_IMPOSSIBLE, nil, nil)
	end
	UnitData:OnPrediction(input.Unit)
	if ft then
		input.Delay = input.Delay + Menu:GetLatency() / 2 + Menu:GetExtraDelay()
		if input.Aoe then
			return AoePrediction:GetPrediction(input)
		end
	end
	if input.Range ~= math_huge and Math:GetDistanceSqr(input.Unit.pos, input.RangeCheckFrom) > (input.Range * 1.5) * (input.Range * 1.5) then
		return self:CreateOutput(input, HITCHANCE_IMPOSSIBLE, nil, nil)
	end
	local result
	if input.Unit.pathing and input.Unit.pathing.isDashing then
		result = self:GetDashingPrediction(input)
	else
		local remainingImmobileT = self:UnitIsImmobileUntil(input.Unit)
		if remainingImmobileT and remainingImmobileT >= 0 then
			result = self:GetImmobilePrediction(input, remainingImmobileT)
		else
			input.Range = input.Range * Menu:GetMaxRange()
		end
	end
	if result == nil or result.CastPosition == nil then
		result = self:GetStandardPrediction(input)
	end
	if input.Range ~= math_huge and result.UnitPosition then
		if result.Hitchance >= HITCHANCE_HIGH and Math:GetDistanceSqr(input.RangeCheckFrom, input.Unit.pos) > (input.Range + input.RealRadius * 3 / 4) ^ 2 then
			result.Hitchance = HITCHANCE_NORMAL
		end
		if Math:GetDistanceSqr(input.RangeCheckFrom, result.UnitPosition) > (input.Range + (input.Type == SPELLTYPE_CIRCLE and input.RealRadius or 0)) ^ 2 then
			result.Hitchance = HITCHANCE_IMPOSSIBLE
		end
		if result.CastPosition and Math:GetDistanceSqr(input.RangeCheckFrom, result.CastPosition) > input.Range * input.Range then
			if result.Hitchance ~= HITCHANCE_IMPOSSIBLE then
				result.CastPosition = Math:ExtendTo(input.RangeCheckFrom, result.UnitPosition, input.Range)
			else
				result.Hitchance = HITCHANCE_IMPOSSIBLE
			end
		end
	end
	if result.Hitchance == HITCHANCE_HIGH then
		result = self:WayPointAnalysis(result, input)
	end
	if checkCollision and input.Collision and result.CastPosition then
		local isWall, collisionObjects, collisionCount = Collision:GetCollision(input.From, result.CastPosition, input.Speed, input.Delay, input.Radius, input.CollisionObjects, input.Unit.networkID, input)
		result.CollisionObjects = collisionObjects
		if isWall or collisionCount > 0 then
			result.Hitchance = HITCHANCE_COLLISION
		end
	end
	result.TimeToHit = result.CastPosition and (input.Delay + (input.Speed == math_huge and 0 or Math:GetDistance(input.From, result.CastPosition) / input.Speed)) or 0
	return result
end

AoePrediction = {}

function AoePrediction:GetPrediction(input)
	if input.Type == SPELLTYPE_CIRCLE then
		return self:GetCirclePrediction(input)
	elseif input.Type == SPELLTYPE_CONE then
		return self:GetConePrediction(input)
	elseif input.Type == SPELLTYPE_LINE then
		return self:GetLinePrediction(input)
	end
	return Prediction:CreateOutput(input, HITCHANCE_IMPOSSIBLE, nil, nil)
end

function AoePrediction:GetPossibleTargets(input)
	local result = {}
	local originalUnit = input.Unit
	local enemies = ObjectManager:GetEnemyHeroes()
	for i = 1, #enemies do
		local enemy = enemies[i]
		if enemy.networkID ~= originalUnit.networkID and Math:IsInRange(enemy.pos, input.RangeCheckFrom, input.Range + 200 + input.RealRadius) then
			local enemyInput = Prediction:CreateInput({
				Unit = enemy,
				From = input.From,
				RangeCheckFrom = input.RangeCheckFrom,
				Speed = input.Speed,
				Delay = input.Delay,
				Radius = input.Radius,
				Range = input.Range,
				Type = input.Type,
				Collision = false,
				CollisionObjects = input.CollisionObjects,
				UseBoundingRadius = input.UseBoundingRadius,
			})
			local prediction = Prediction:GetPredictionOutput(enemyInput, false, false)
			if prediction.Hitchance >= HITCHANCE_HIGH and prediction.UnitPosition then
				table_insert(result, { Position = prediction.UnitPosition, Unit = enemy })
			end
		end
	end
	input.Unit = originalUnit
	return result
end

function AoePrediction:GetCirclePrediction(input)
	local mainTargetPrediction = Prediction:GetPredictionOutput(input, false, true)
	if not mainTargetPrediction.UnitPosition then
		return mainTargetPrediction
	end
	local possibleTargets = { { Position = mainTargetPrediction.UnitPosition, Unit = input.Unit } }
	if mainTargetPrediction.Hitchance >= HITCHANCE_NORMAL then
		local extraTargets = self:GetPossibleTargets(input)
		for i = 1, #extraTargets do
			table_insert(possibleTargets, extraTargets[i])
		end
	end
	while #possibleTargets > 1 do
		local points = {}
		for i = 1, #possibleTargets do
			table_insert(points, possibleTargets[i].Position)
		end
		local mecCircle = Math:GetMEC(points)
		if mecCircle.Radius <= input.RealRadius - 10 and Math:GetDistanceSqr(mecCircle.Center, input.RangeCheckFrom) < input.Range * input.Range then
			local output = Prediction:CreateOutput(input, mainTargetPrediction.Hitchance, mecCircle.Center, mainTargetPrediction.UnitPosition)
			output.AoeTargetsHit = {}
			for i = 1, #possibleTargets do
				table_insert(output.AoeTargetsHit, possibleTargets[i].Unit)
			end
			output.AoeTargetsHitCount = #possibleTargets
			return output
		end
		local maxdist = -1
		local maxdistindex = 2
		for i = 2, #possibleTargets do
			local distance = Math:GetDistanceSqr(possibleTargets[i].Position, possibleTargets[1].Position)
			if distance > maxdist then
				maxdistindex = i
				maxdist = distance
			end
		end
		table_remove(possibleTargets, maxdistindex)
	end
	return mainTargetPrediction
end

function AoePrediction:GetConeHits(endPos, range, angle, targets)
	local result = {}
	local edge1 = Math:Rotate(endPos, -angle / 2)
	local edge2 = Math:Rotate(edge1, angle)
	for i = 1, #targets do
		local point = targets[i].Position
		if Math:GetDistanceSqr(point, { x = 0, z = 0 }) < range * range and Math:Cross(edge1, point) > 0 and Math:Cross(point, edge2) > 0 then
			table_insert(result, targets[i])
		end
	end
	return result
end

function AoePrediction:GetConePrediction(input)
	local mainTargetPrediction = Prediction:GetPredictionOutput(input, false, true)
	if not mainTargetPrediction.UnitPosition then
		return mainTargetPrediction
	end
	local possibleTargets = { { Position = mainTargetPrediction.UnitPosition, Unit = input.Unit } }
	if mainTargetPrediction.Hitchance >= HITCHANCE_NORMAL then
		local extraTargets = self:GetPossibleTargets(input)
		for i = 1, #extraTargets do
			table_insert(possibleTargets, extraTargets[i])
		end
	end
	if #possibleTargets > 1 then
		local candidates = {}
		for i = 1, #possibleTargets do
			possibleTargets[i].Position = Math:Sub(possibleTargets[i].Position, input.From)
		end
		for i = 1, #possibleTargets do
			for j = 1, #possibleTargets do
				if i ~= j then
					local p = Math:Div(Math:Add(possibleTargets[i].Position, possibleTargets[j].Position), 2)
					local exists = false
					for k = 1, #candidates do
						if Math:VectorsEqual(candidates[k], p, 1) then
							exists = true
							break
						end
					end
					if not exists then
						table_insert(candidates, p)
					end
				end
			end
		end
		local targetsHit = {}
		local bestCandidateHits = -1
		local bestCandidate = nil
		for i = 1, #candidates do
			local hits = self:GetConeHits(candidates[i], input.Range, input.Radius, possibleTargets)
			if #hits > bestCandidateHits then
				targetsHit = hits
				bestCandidate = candidates[i]
				bestCandidateHits = #hits
			end
		end
		if bestCandidate and bestCandidateHits > 1 and Math:GetDistanceSqr({ x = 0, z = 0 }, bestCandidate) > 50 * 50 then
			local output = Prediction:CreateOutput(input, mainTargetPrediction.Hitchance, Math:Add(bestCandidate, input.From), mainTargetPrediction.UnitPosition)
			for i = 1, #targetsHit do
				table_insert(output.AoeTargetsHit, targetsHit[i].Unit)
			end
			output.AoeTargetsHitCount = bestCandidateHits
			return output
		end
	end
	return mainTargetPrediction
end

function AoePrediction:GetLineCandidates(from, to, radius, range)
	local middlePoint = Math:Div(Math:Add(from, to), 2)
	local intersections = Math:CircleCircleIntersection(from, middlePoint, radius, Math:GetDistance(from, middlePoint))
	local result = {}
	if #intersections > 1 then
		table_insert(result, Math:Extended(from, Math:Normalized(to, intersections[1]), range))
		table_insert(result, Math:Extended(from, Math:Normalized(to, intersections[2]), range))
	end
	return result
end

function AoePrediction:GetLineHits(startPos, endPos, radius, targets)
	local result = {}
	if targets == nil then
		return result
	end
	for i = 1, #targets do
		local dist = Math:DistanceToLineSegmentSqr(targets[i].Position, startPos, endPos)
		if dist <= radius * radius then
			table_insert(result, targets[i])
		end
	end
	return result
end

function AoePrediction:GetLinePrediction(input)
	local mainTargetPrediction = Prediction:GetPredictionOutput(input, false, true)
	if not mainTargetPrediction.UnitPosition then
		return mainTargetPrediction
	end
	local possibleTargets = { { Position = mainTargetPrediction.UnitPosition, Unit = input.Unit } }
	if mainTargetPrediction.Hitchance >= HITCHANCE_NORMAL then
		local extraTargets = self:GetPossibleTargets(input)
		for i = 1, #extraTargets do
			table_insert(possibleTargets, extraTargets[i])
		end
	end
	if #possibleTargets > 1 then
		local candidates = {}
		for i = 1, #possibleTargets do
			local targetCandidates = self:GetLineCandidates(input.From, possibleTargets[i].Position, input.Radius, input.Range)
			for j = 1, #targetCandidates do
				table_insert(candidates, targetCandidates[j])
			end
		end
		local targetsHit = {}
		local bestCandidateHits = -1
		local bestCandidate = nil
		local bestCandidateHitPoints = {}
		local positionsList = {}
		for i = 1, #possibleTargets do
			table_insert(positionsList, possibleTargets[i].Position)
		end
		for i = 1, #candidates do
			local mainHits = self:GetLineHits(input.From, candidates[i], input.Radius + input.Unit.boundingRadius / 3 - 10, { possibleTargets[1] })
			if #mainHits == 1 then
				local hits = self:GetLineHits(input.From, candidates[i], input.Radius, possibleTargets)
				if #hits >= bestCandidateHits then
					targetsHit = hits
					bestCandidateHits = #hits
					bestCandidate = candidates[i]
					bestCandidateHitPoints = {}
					for j = 1, #hits do
						table_insert(bestCandidateHitPoints, hits[j].Position)
					end
				end
			end
		end
		if bestCandidate and bestCandidateHits > 1 then
			local maxDistance = -1
			local p1, p2 = positionsList[1], positionsList[1]
			for i = 1, #bestCandidateHitPoints do
				for j = 1, #bestCandidateHitPoints do
					local proj1 = Math:ProjectOn(positionsList[i], input.From, bestCandidate)
					local proj2 = Math:ProjectOn(positionsList[j], input.From, bestCandidate)
					local dist = Math:GetDistanceSqr(bestCandidateHitPoints[i], proj1.LinePoint) + Math:GetDistanceSqr(bestCandidateHitPoints[j], proj2.LinePoint)
					local angle = Math:AngleBetween(Math:Sub(proj1.LinePoint, positionsList[i]), Math:Sub(proj2.LinePoint, positionsList[j])) or 0
					if dist >= maxDistance and angle > 90 then
						maxDistance = dist
						p1 = positionsList[i]
						p2 = positionsList[j]
					end
				end
			end
			local output = Prediction:CreateOutput(input, mainTargetPrediction.Hitchance, Math:Div(Math:Add(p1, p2), 2), mainTargetPrediction.UnitPosition)
			for i = 1, #targetsHit do
				table_insert(output.AoeTargetsHit, targetsHit[i].Unit)
			end
			output.AoeTargetsHitCount = bestCandidateHits
			return output
		end
	end
	return mainTargetPrediction
end

function Prediction:GetPrediction(target, source, speed, delay, radius, isHero)
	local id, ms, ds = target.networkID, target.ms, target.pathing.dashSpeed
	if not isHero then
		local hasMovePath = target.pathing.hasMovePath
		if not hasMovePath then
			return Math:Get2D(target.pos)
		end
		local path = Path:GetPath(target)
		if #path <= 1 then
			return Math:Get2D(target.pos)
		end
		local delay2 = delay + Menu:GetLatency() / 2 + Menu:GetExtraDelay()
		local path2 = Path:CutPath(path, ms * delay2)
		if speed == math_huge then
			return path2[1]
		end
		local path3, time = Path:GetPredictedPath(source, speed, ms, path)
		if path3 then
			return path3[#path3]
		end
		return path[#path]
	end
	UnitData:OnPrediction(target)
	local vis = UnitData.Visible[id]
	if vis.visible then
		if GetTickCount() < vis.visibleTick + 500 then
			return nil, nil, -1
		end
	elseif GetTickCount() > vis.invisibleTick + 1000 then
		return nil, nil, -1
	end
	local wp = UnitData.Waypoints[id]
	if wp.moving and #wp.path <= 1 then
		return nil, nil, -1
	end
	if not wp.moving then
		local pos = Math:Get2D(target.pos)
		return pos, pos, delay + Math:GetDistance(pos, source) / speed
	end
	local delay2 = delay + Menu:GetLatency() / 2 + Menu:GetExtraDelay()
	local moveSpeed = ms
	if wp.dashing then
		moveSpeed = ds > 0 and ds or ms
	end
	if speed == math_huge then
		local path = Path:CutPath(wp.path, moveSpeed * delay2)
		local path2 = Path:CutPath(wp.path, moveSpeed * delay2 - radius * 0.5)
		return path[1], wp.dashing and path[1] or path2[1], delay
	end
	local path, time = Path:GetPredictedPath(source, speed, moveSpeed, Path:CutPath(wp.path, moveSpeed * delay2))
	if path then
		local path2 = Path:CutPath(Path:ReversePath(path), radius)
		return path[#path], wp.dashing and path[#path] or path2[1], delay + Math:GetDistance(path[#path], source) / speed
	end
	local p = wp.path[#wp.path]
	return p, p, delay + Math:GetDistance(p, source) / speed
end

function Prediction:SpellPrediction(args)
	local c = {}
	do -- __init()
		c.Collision, c.MaxCollision, c.CollisionTypes = false, 0, { 0, 3 }
		if args.Collision ~= nil then
			c.Collision = args.Collision
		end
		if args.MaxCollision ~= nil then
			c.MaxCollision = args.MaxCollision
		end
		if args.CollisionTypes ~= nil then
			c.CollisionTypes = args.CollisionTypes
		end
		c.Type, c.Speed, c.Range, c.Delay, c.Radius, c.UseBoundingRadius =
			SPELLTYPE_LINE, math_huge, math_huge, 0, 1, false
		if args.Type ~= nil then
			c.Type = args.Type
		end
		if args.Speed ~= nil then
			c.Speed = args.Speed
		end
		if args.Range ~= nil then
			c.Range = args.Range
		end
		if args.Delay ~= nil then
			c.Delay = args.Delay
		end
		if args.Radius ~= nil then
			c.Radius = args.Radius
		end
		if args.UseBoundingRadius or (args.UseBoundingRadius == nil and c.Type == SPELLTYPE_LINE) then
			c.UseBoundingRadius = true
		end
	end
	function c:ResetOutput()
		self.HitChance = HITCHANCE_IMPOSSIBLE
		self.CastPosition = nil
		self.UnitPosition = nil
		self.TimeToHit = 0
		self.CollionableObjects = {}
		self.CollisionObjects = self.CollionableObjects
		self.AoeTargetsHit = {}
		self.AoeTargetsHitCount = 0
	end
	function c:GetOutput()
		self.TargetIsHero = self.Target.type == Obj_AI_Hero
		self.RealRadius = self.UseBoundingRadius and self.Radius + self.Target.boundingRadius or self.Radius
		local output = Prediction:GetPredictionOutput(Prediction:CreateInput({
			Unit = self.Target,
			From = self.Source,
			RangeCheckFrom = self.Source,
			Speed = self.Speed,
			Delay = self.Delay,
			Radius = self.Radius,
			Range = self.Range,
			Type = self.Type,
			Collision = false,
			CollisionObjects = self.CollisionTypes,
			UseBoundingRadius = self.UseBoundingRadius,
		}), true, false)
		self.Output = output
		self.UnitPosition = output.UnitPosition
		self.CastPosition = output.CastPosition
		self.TimeToHit = output.TimeToHit
		self.HitChance = output.Hitchance
		self.AoeTargetsHit = output.AoeTargetsHit
		self.AoeTargetsHitCount = output.AoeTargetsHitCount
	end
	function c:HighHitChance()
		local wp, tick = UnitData.Waypoints[self.Target.networkID], GetTickCount()
		if not self.Target.visible then
			return false
		end
		if wp.moving then
			if wp.dashing then
				return true
			end
			if tick < wp.tick + 150 then
				return true
			end
			if tick > wp.tick + 1000 and Path:GetLenght(wp.path) > 1000 then
				return true
			end
			return false
		end
		if tick - wp.stoptick < 50 then
			return true
		end
		if tick - wp.stoptick > 1000 then
			return true
		end
		return false
	end
	function c:IsCollision()
		local isWall, collisionObjects, collisionCount = Collision:GetCollision(
			self.Source,
			self.CastPosition,
			self.Speed,
			self.Delay,
			self.Radius,
			self.CollisionTypes,
			self.Target.networkID
		)
		if isWall or collisionCount > self.MaxCollision then
			self.CollionableObjects = collisionObjects
			self.CollisionObjects = collisionObjects
			self.HitChance = HITCHANCE_COLLISION
			return true
		end
		return false
	end
	function c:IsInRange()
		if Math:IsInRange(self.CastPosition, self.Source, self.Range * Menu:GetMaxRange()) then
			local y = self.Target.pos.y
			y = y > 100 and 100 or y
			self.CastPosition.y = y
			self.UnitPosition.y = y
			local castPos3D = Math:Get3D(self.CastPosition)
			self.IsOnScreen = castPos3D:To2D().onScreen
			if not self.IsOnScreen then
				if self.Type == SPELLTYPE_CIRCLE then
					return false
				end
				self.CastPosition = myHero.pos:Extended(castPos3D, 800)
			end
			return true
		end
		return false
	end
	function c:CanHit(hitChance)
		hitChance = hitChance or HITCHANCE_NORMAL
		if self.UnitPosition == nil or self.CastPosition == nil then
			self.HitChance = HITCHANCE_IMPOSSIBLE
			return false
		end
		--[[if self.Type ~= SPELLTYPE_CIRCLE and self.TimeToHit > 0.7 and Math:FindAngle(self.CastPosition, self.Target.pos, myHero.pos) > 90 - self.TimeToHit * 30 then
			return false
		end]]
		self.HitChance = HITCHANCE_NORMAL
		if self.Output and self.Output.Hitchance then
			self.HitChance = self.Output.Hitchance
		end
		if self.TargetIsHero then
			local duration, spelltime, attacktime, knockduration, slowduration = Immobile:GetDuration(self.Target)
			if knockduration ~= 0 then
				self.HitChance = HITCHANCE_IMPOSSIBLE
				return false
			end
			if duration > 0 then
				if self.TimeToHit + 0.02 < duration + self.RealRadius / self.Target.ms then
					self.HitChance = HITCHANCE_IMMOBILE
					local currentPos = Math:Get2D(self.Target.pos)
					self.CastPosition = currentPos
					self.UnitPosition = currentPos
				end
			end
			if self.HitChance == HITCHANCE_NORMAL then
				local timer = Game.Timer()
				if (attacktime - 0.05 > timer) or (spelltime - 0.05 > timer) then
					self.HitChance = math_max(self.HitChance, HITCHANCE_HIGH)
					local currentPos = Math:Get2D(self.Target.pos)
					self.CastPosition = currentPos
					self.UnitPosition = currentPos
				elseif self:HighHitChance() or slowduration > 0 then
					self.HitChance = math_max(self.HitChance, HITCHANCE_HIGH)
					self:GetOutput()
				end
			end
		end
		if self.Range ~= math_huge and not self:IsInRange() then
			self.HitChance = HITCHANCE_IMPOSSIBLE
			return false
		end
		if self.Collision and self:IsCollision() then
			return false
		end
		if self.HitChance < hitChance then
			return false
		end
		if not Math:VectorsEqual(self.PosTo, Math:Get2D(self.Target.posTo), 50) then
			return false
		end
		if os.clock() - self.StartTime > 0.05 then
			--print("PREDICTION TIMER")
			return false
		end
		return true
	end
	function c:GetPrediction(target, source)
		self.Target = target
		self.Source = Math:Get2D(source)
		self.PosTo = Math:Get2D(target.posTo)
		self.StartTime = os.clock()
		self:ResetOutput()
		self:GetOutput()
	end
	function c:GetAOEPrediction(source)
		local result = {}
		local enemies = ObjectManager:GetEnemyHeroes()
		for i = 1, #enemies do
			local enemy = enemies[i]
			local immortal = _G.SDK and SDK.ObjectManager and SDK.ObjectManager.IsHeroImmortal and SDK.ObjectManager:IsHeroImmortal(enemy)
			if not immortal then
				local input = Prediction:CreateInput({
					Unit = enemy,
					From = source,
					RangeCheckFrom = source,
					Speed = self.Speed,
					Delay = self.Delay,
					Radius = self.Radius,
					Range = self.Range,
					Type = self.Type,
					Aoe = true,
					Collision = false,
					UseBoundingRadius = self.UseBoundingRadius,
				})
				local output = Prediction:GetPredictionOutput(input, true, false)
				if output and output.CastPosition and output.Hitchance >= HITCHANCE_NORMAL then
					table_insert(result, {
						Count = output.AoeTargetsHitCount > 0 and output.AoeTargetsHitCount or 1,
						Distance = 0,
						Unit = enemy,
						HitChance = output.Hitchance,
						TimeToHit = output.TimeToHit,
						CastPosition = output.CastPosition,
						AoeTargetsHit = output.AoeTargetsHit,
					})
				end
			end
		end
		return result
	end
	return c
end
--[[
	GGPrediction - Global Class, API
]]
_G.GGPrediction = {
	COLLISION_MINION = COLLISION_MINION,
	COLLISION_ALLYHERO = COLLISION_ALLYHERO,
	COLLISION_ENEMYHERO = COLLISION_ENEMYHERO,
	COLLISION_YASUOWALL = COLLISION_YASUOWALL,
	HITCHANCE_IMPOSSIBLE = HITCHANCE_IMPOSSIBLE,
	HITCHANCE_COLLISION = HITCHANCE_COLLISION,
	HITCHANCE_NORMAL = HITCHANCE_NORMAL,
	HITCHANCE_HIGH = HITCHANCE_HIGH,
	HITCHANCE_VERY_HIGH = HITCHANCE_VERY_HIGH,
	HITCHANCE_IMMOBILE = HITCHANCE_IMMOBILE,
	HITCHANCE_DASHING = HITCHANCE_DASHING,
	SPELLTYPE_LINE = SPELLTYPE_LINE,
	SPELLTYPE_CIRCLE = SPELLTYPE_CIRCLE,
	SPELLTYPE_CONE = SPELLTYPE_CONE,
}
function GGPrediction:GetPrediction(target, source, speed, delay, radius)
	local output = Prediction:GetPredictionOutput(Prediction:CreateInput({
		Unit = target,
		From = source,
		RangeCheckFrom = source,
		Speed = speed,
		Delay = delay,
		Radius = radius,
		Range = math_huge,
		Type = SPELLTYPE_LINE,
		Collision = false,
		UseBoundingRadius = true,
	}), true, false)
	return output.UnitPosition, output.CastPosition, output.TimeToHit, output
end
function GGPrediction:GetPredictionOutput(args)
	return Prediction:GetPredictionOutput(Prediction:CreateInput(args), true, true)
end
function GGPrediction:GetCollision(source, castPos, speed, delay, radius, collisionTypes, skipID)
	return Collision:GetCollision(source, castPos, speed, delay, radius, collisionTypes, skipID)
end
function GGPrediction:SpellPrediction(args)
	return Prediction:SpellPrediction(args)
end
function GGPrediction:ClosestPointOnLineSegment(p, p1, p2)
	return Math:ClosestPointOnLineSegment(p, p1, p2)
end
function GGPrediction:IsInRange(p1, p2, range)
	return Math:IsInRange(p1, p2, range)
end
function GGPrediction:GetImmobileDuration(unit)
	return Immobile:GetDuration(unit)
end
function GGPrediction:FindAngle(p1, center, p2)
	return Math:FindAngle(p1, center, p2)
end
function GGPrediction:GetDistance(p1, p2)
	return Math:GetDistance(p1, p2)
end
function GGPrediction:CircleCircleIntersection(center1, center2, radius1, radius2)
	return Math:CircleCircleIntersection(center1, center2, radius1, radius2)
end
